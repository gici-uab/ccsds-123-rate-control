#!/bin/bash

# Filename: validationTest.sh
#
# Author: jgonzalez@deic.uab.es
# Date:   Wednesday Jan 23, 2008
# Last modification: 
#
# Description: script for validate the implementation of the Gcomp application

./validationTestCorpora.sh
./validationTestCorporaSA.sh
