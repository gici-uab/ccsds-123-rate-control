Test images for Gstat and Moran's I measure.
All images are 1000x1000, 16bpp and big endian.

chess.raw	 - Chess, 1x1 texture. With the 8 neighbours, Moran's I is close to 0 (almost random).
chess2.raw	 - Chess, 2x2 texture. With the 8 neighbours, Moran's I is close to 0 (almost random).
horizontal.raw	 - Two horizonal stripes. Moran's I is close to 1
vertical.raw     - Two vertical stripes. Moran's I is close to 1
hstripes.raw     - Plenty Yx1 horizontal stripes. Moran's I is close to 1/2
vstripes.raw	 - Plenty 1xX vertical stripes. Moran's I is close to 1/2.
random.raw       - Random image. Moran's I is very close to 1



